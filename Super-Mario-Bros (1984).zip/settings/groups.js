FullScreenMario.FullScreenMario.settings.groups = {
    "groupNames": ["Solid", "Character", "Scenery", "Text"],
    "groupTypes": "Array",
};
